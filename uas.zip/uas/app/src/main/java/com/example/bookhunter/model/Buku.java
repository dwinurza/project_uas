package com.example.bookhunter.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.HashMap;
import java.util.Map;

public class Buku implements Parcelable {
    private String kodeBuku;
    private String kodeKategori;
    private String kodePenerbit;
    private String judul;
    private String sinopsis;
    private String pengarang;
    private Integer thnTerbit;
    private String coverBuku;
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public String getKodeBuku() {
        return kodeBuku;
    }

    public void setKodeBuku(String kodeBuku) {
        this.kodeBuku = kodeBuku;
    }

    public String getKodeKategori() {
        return kodeKategori;
    }

    public void setKodeKategori(String kodeKategori) {
        this.kodeKategori = kodeKategori;
    }

    public String getKodePenerbit() {
        return kodePenerbit;
    }

    public void setKodePenerbit(String kodePenerbit) {
        this.kodePenerbit = kodePenerbit;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(String sinopsis) {
        this.sinopsis = sinopsis;
    }

    public String getPengarang() {
        return pengarang;
    }

    public void setPengarang(String pengarang) {
        this.pengarang = pengarang;
    }

    public Integer getThnTerbit() {
        return thnTerbit;
    }

    public void setThnTerbit(Integer thnTerbit) {
        this.thnTerbit = thnTerbit;
    }

    public String getCoverBuku() {
        return coverBuku;
    }

    public void setCoverBuku(String coverBuku) {
        this.coverBuku = coverBuku;
    }

    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.kodeBuku);
        dest.writeString(this.kodeKategori);
        dest.writeString(this.kodePenerbit);
        dest.writeString(this.judul);
        dest.writeString(this.sinopsis);
        dest.writeString(this.pengarang);
        dest.writeValue(this.thnTerbit);
        dest.writeString(this.coverBuku);
        dest.writeInt(this.additionalProperties.size());
        for (Map.Entry<String, Object> entry : this.additionalProperties.entrySet()) {
            dest.writeString(entry.getKey());
            dest.writeParcelable((Parcelable) entry.getValue(), flags);
        }
    }

    public Buku() {
    }

    protected Buku(Parcel in) {
        this.kodeBuku = in.readString();
        this.kodeKategori = in.readString();
        this.kodePenerbit = in.readString();
        this.judul = in.readString();
        this.sinopsis = in.readString();
        this.pengarang = in.readString();
        this.thnTerbit = (Integer) in.readValue(Integer.class.getClassLoader());
        this.coverBuku = in.readString();
        int additionalPropertiesSize = in.readInt();
        this.additionalProperties = new HashMap<String, Object>(additionalPropertiesSize);
        for (int i = 0; i < additionalPropertiesSize; i++) {
            String key = in.readString();
            Object value = in.readParcelable(Object.class.getClassLoader());
            this.additionalProperties.put(key, value);
        }
    }

    public static final Parcelable.Creator<Buku> CREATOR = new Parcelable.Creator<Buku>() {
        @Override
        public Buku createFromParcel(Parcel source) {
            return new Buku(source);
        }

        @Override
        public Buku[] newArray(int size) {
            return new Buku[size];
        }
    };
}
