package com.example.bookhunter.view.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.bookhunter.R;
import com.example.bookhunter.model.Buku;

public class IslamiActivity extends AppCompatActivity {
    public static final String EXTRA_ISLAMI = "extra_islami" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_islami);

        Buku buku = getIntent().getParcelableExtra(EXTRA_ISLAMI);
    }
}
