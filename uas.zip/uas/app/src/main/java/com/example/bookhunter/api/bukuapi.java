package com.example.bookhunter.api;

import com.example.bookhunter.adapter.BookAdapter;
import com.example.bookhunter.model.Buku;

import retrofit2.Call;
import retrofit2.http.GET;

public interface bukuapi {

    @GET("data_buku.php")
    Call<Buku> getBuku();
}
