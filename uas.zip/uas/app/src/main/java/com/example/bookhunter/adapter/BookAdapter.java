package com.example.bookhunter.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.bookhunter.model.ListBuku;
import com.example.bookhunter.view.view.BiografiActivity;
import com.example.bookhunter.view.view.EnsiklopediaActivity;
import com.example.bookhunter.R;
import com.example.bookhunter.model.Buku;
import com.example.bookhunter.view.view.FiksiActivity;
import com.example.bookhunter.view.view.HorrorActivity;
import com.example.bookhunter.view.view.IslamiActivity;
import com.example.bookhunter.view.view.NovelActivity;

import java.util.ArrayList;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter <BookAdapter.MyViewHolder>{

    private List <Buku> books;
    private Context context;

    public BookAdapter(Context context) {
        this.context = context;
    }

    public BookAdapter(List<Buku> books) {
        this.books = books;
    }

    public BookAdapter(List<Buku> books, Context context) {
        this.books = books;
        this.context = context;
    }

    @NonNull
    @Override
    public BookAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

       View view = LayoutInflater.from(viewGroup.getContext()).inflate( R.layout.fragment_home , viewGroup,false);
       MyViewHolder myViewHolder = new MyViewHolder(view);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final BookAdapter.MyViewHolder myViewHolder, final int i) {
        final Buku buku = books.get(i);

        myViewHolder.btnEnsiklopedia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(EnsiklopediaActivity.class));
                intent.putExtra(EnsiklopediaActivity.EXTRA_ENSIKLOPEDIA, (Parcelable) books);
            }
        });
        myViewHolder.btnRemaja.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(FiksiActivity.class));
                intent.putExtra(FiksiActivity.EXTRA_FIKSI, (Parcelable)books);
            }
        });
        myViewHolder.btnNovel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(NovelActivity.class));
                intent.putExtra(NovelActivity.EXTRA_NOVEL, (Parcelable)books);
            }
        });
        myViewHolder.btnHorror.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(HorrorActivity.class));
                intent.putExtra(HorrorActivity.EXTRA_HORROR,(Parcelable)books);
            }
        });
        myViewHolder.btnIslami.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(IslamiActivity.class));
                intent.putExtra(IslamiActivity.EXTRA_ISLAMI,(Parcelable)books);
            }
        });
        myViewHolder.btnBiografi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(BiografiActivity.class));
                intent.putExtra(BiografiActivity.EXTRA_BIOGRAFI,(Parcelable)books);
            }
        });


        // Intent intent = new Intent(this, EnsiklopediaActivity.class);
        // intent.putExtra(EnsiklopediaActivity.EXTRA_ENSIKLOPEDIA, books.get(i));
        //  startActivity(intent);

    }



    @Override
    public int getItemCount() {
        return books.size();
    }

    public void setBook(ArrayList<ListBuku> listBukus) {
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public Button btnEnsiklopedia;
        public Button btnBiografi;
        public Button btnHorror;
        public Button btnRemaja;
        public Button btnNovel;
        public Button btnIslami;
        public MyViewHolder(@NonNull View itemView) {

            super(itemView);
            btnEnsiklopedia = itemView.findViewById(R.id.ensiklopedia);
            btnBiografi = itemView.findViewById(R.id.biografi);
            btnHorror = itemView.findViewById(R.id.horror);
            btnIslami = itemView.findViewById(R.id.islami);
            btnNovel = itemView.findViewById(R.id.novel);
            btnRemaja = itemView.findViewById(R.id.remaja);

        }
    }
}
