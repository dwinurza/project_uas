package com.example.bookhunter.view.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;

import com.example.bookhunter.R;
import com.example.bookhunter.model.Buku;

public class EnsiklopediaActivity extends AppCompatActivity {
    public static final String EXTRA_ENSIKLOPEDIA = "extra_ensiklopedia" ;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ensiklopedia);
        setContentView(R.layout.activity_biografi);
        recyclerView = findViewById(R.id.recycleviewbiografi);
        Buku buku = getIntent().getParcelableExtra(EXTRA_ENSIKLOPEDIA);
    }
}
