package com.example.bookhunter.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bookhunter.R;
import com.example.bookhunter.model.ListBuku;
import com.example.bookhunter.view.view.DetailBook;

import java.util.ArrayList;

public class BookListAdapter extends RecyclerView.Adapter<BookListAdapter.ViewHolder> {
    private Context context;
    private ArrayList<ListBuku> Bukus;

    public BookListAdapter(ArrayList<ListBuku> bukus) {
        Bukus = bukus;
    }

    public BookListAdapter(Context context) {
        this.context = context;
    }
    public ArrayList<ListBuku>getBukus(){
        return  Bukus;
    }

    @NonNull
    @Override
    public BookListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row, viewGroup, false);
        return new ViewHolder(view) ;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        ArrayList<ListBuku> listBuku = getBukus();
//        viewHolder.tvTitle.setText getTitle);
//        viewHolder.tvAuthor.setText(listBuku.getAuthor());
//        viewHolder.image.setImageResource(listBuku.getImage());

    }

    @Override
    public int getItemCount() {
        return getBukus().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView tvAuthor;
        ImageView image;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.title);
            tvAuthor = itemView.findViewById(R.id.pengarang);
            image = itemView.findViewById(R.id.poster);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int i =getAdapterPosition();
                    Intent intent = new Intent(context, DetailBook.class);
                    context.startActivity(intent);
                }
            });

        }
    }



}
