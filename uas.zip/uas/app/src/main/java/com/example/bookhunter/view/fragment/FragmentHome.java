package com.example.bookhunter.view.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.bookhunter.R;
import com.example.bookhunter.view.view.BiografiActivity;
import com.example.bookhunter.view.view.EnsiklopediaActivity;
import com.example.bookhunter.view.view.FiksiActivity;
import com.example.bookhunter.view.view.HorrorActivity;
import com.example.bookhunter.view.view.NovelActivity;

public class FragmentHome extends Fragment {

    private Button fiksi,  biografi, ensiklo, islami, horror, novel;
    //buttonnya namanya remaja ini udah di define kan fiksi adalah BUtton langsung aja atau variablenya dibikin undefien


    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
       // View view = inflater.inflate(R.layout.fragment_home, container, false);
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.fragment_home, container, false);
        fiksi = (Button)view.findViewById (R.id.buttonremaja);
        fiksi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(FiksiActivity.class));
                startActivity(intent);

            };
        });
        biografi = (Button)view.findViewById (R.id.buttonbiografi);
        biografi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(BiografiActivity.class));
                startActivity(intent);

            };
        });
        ensiklo = (Button)view.findViewById (R.id.buttonensiklopedia);
        ensiklo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(EnsiklopediaActivity.class));
                startActivity(intent);

            };
        });
        horror = (Button)view.findViewById (R.id.buttonhorror);
        horror.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(HorrorActivity.class));
                startActivity(intent);

            };
        });
        novel = (Button)view.findViewById (R.id.buttonnovel);
        novel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(String.valueOf(NovelActivity.class));
                startActivity(intent);

            };
        });


        return view;

}
//
}














