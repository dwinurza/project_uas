package com.example.bookhunter.view.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.example.bookhunter.R;
import com.example.bookhunter.model.Buku;

public class FiksiActivity extends AppCompatActivity {
    public static final String EXTRA_FIKSI = "extra_fiksi" ;

    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fiksi);

        recyclerView = findViewById(R.id.recycleviewfiksi);
        Buku buku = getIntent().getParcelableExtra(EXTRA_FIKSI);
    }
}
