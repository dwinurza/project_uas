package com.example.bookhunter.adapter;

public class ListAdapter {
}
